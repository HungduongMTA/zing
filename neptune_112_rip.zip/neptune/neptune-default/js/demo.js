$(document).ready(function(){

	/* Waves */
 	Waves.init();

});